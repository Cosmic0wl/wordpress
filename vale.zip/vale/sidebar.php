<div class="col-4">
	<h4 class="text-darkerblue">Elsewhere</h4>
	<ol class="list-group">
	  <li class="list-group-item"><a href="#">GitHub</a></li>
	  <li class="list-group-item"><a href="#">Twitter</a></li>
	  <li class="list-group-item"><a href="#">Facebook</a></li>
	</ol>
</div>